let shapes = [];
let backgroundColor;
let seed;
let synth;
let notes = [['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4'], ['C3', 'E3', 'G3', 'B3', 'D4', 'F4', 'A4']];
let currentScale = 0;
let amplitude;

function setup() {
  createCanvas(windowWidth, windowHeight);
  seed = Math.floor(random(1000000));
  randomSeed(seed);
  noiseSeed(seed);

  backgroundColor = color(random(255), random(255), random(255));
  background(backgroundColor);

  synth = new p5.MonoSynth();
  amplitude = new p5.Amplitude();

  for (let i = 0; i < 3; i++) {
    shapes.push(createRandomShape());
  }

  playMusic();
}

function draw() {
  background(backgroundColor);
  let level = amplitude.getLevel();

  for (let i = 0; i < shapes.length; i++) {
    shapes[i].update(level);
    shapes[i].display();
    
    for (let j = i + 1; j < shapes.length; j++) {
      if (shapes[i].checkCollision(shapes[j])) {
        shapes[i].changeDirection();
        shapes[j].changeDirection();
      }
    }
  }
}

function mousePressed() {
  shapes.push(createRandomShape(mouseX, mouseY));
  currentScale = (currentScale + 1) % notes.length;
}

function createRandomShape(x, y) {
  x = x || random(width);
  y = y || random(height);
  let size = random(30, 80);
  let numPoints = floor(random(3, 6));
  let speed = random(2, 5);
  let direction = random(TWO_PI);
  let shapeColor = color(random(255), random(255), random(255));
  return new Shape(x, y, size, numPoints, speed, direction, shapeColor);
}

function playMusic() {
  let note = random(notes[currentScale]);
  let duration = random(0.2, 0.5);
  let velocity = random(0.3, 0.8);
  
  synth.play(note, velocity, 0, duration);
  
  let interval = random(0.3, 1.5);
  setTimeout(playMusic, interval * 1000);
}

class Shape {
  constructor(x, y, size, numPoints, speed, direction, color) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.numPoints = numPoints;
    this.speed = speed;
    this.direction = direction;
    this.color = color;
  }

  update(level) {
    this.x += cos(this.direction) * this.speed * (1 + level * 2);
    this.y += sin(this.direction) * this.speed * (1 + level * 2);
    
    if (this.x > width + this.size || this.x < -this.size) {
      this.direction = PI - this.direction;
    }
    if (this.y > height + this.size || this.y < -this.size) {
      this.direction = -this.direction;
    }
  }

  display() {
    fill(this.color);
    noStroke();
    beginShape();
    for (let i = 0; i < this.numPoints; i++) {
      let angle = TWO_PI / this.numPoints * i;
      let px = this.x + cos(angle) * this.size;
      let py = this.y + sin(angle) * this.size;
      vertex(px, py);
    }
    endShape(CLOSE);
  }

  checkCollision(other) {
    let d = dist(this.x, this.y, other.x, other.y);
    return d < (this.size + other.size) / 2;
  }

  changeDirection() {
    this.direction = random(TWO_PI);
    this.speed = random(2, 5);
  }
}