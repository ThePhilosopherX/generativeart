let particles = [];
let colors = [
  { type: 'Electron', color: '#00FFFF' },
  { type: 'Proton', color: '#FF0000' },
  { type: 'Neutron', color: '#808080' },
  { type: 'Photon', color: '#FFFF00' },
  { type: 'Muon', color: '#FF00FF' }
];
let bgColor;
let maxParticles = 50;
let collisionSounds = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  bgColor = color(random(50, 150), random(50, 150), random(50, 150));
  let numParticles = int(random(5, 15));
  for (let i = 0; i < numParticles; i++) {
    particles.push(new QuantumParticle(random(width), random(height)));
  }
  for (let i = 0; i < 10; i++) {
    let osc = new p5.Oscillator();
    osc.setType('sine');
    osc.freq(random(200, 1000));
    osc.amp(0);
    osc.start();
    collisionSounds.push(osc);
  }
}

function draw() {
  background(bgColor);
  for (let p of particles) {
    p.update();
    p.display();
  }
  checkCollisions();
}

function mousePressed() {
  if (particles.length < maxParticles) {
    particles.push(new QuantumParticle(mouseX, mouseY));
  }
}

class QuantumParticle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
    this.ax = random(-0.05, 0.05);
    this.ay = random(-0.05, 0.05);
    this.size = random(10, 20);
    this.type = random(colors);
    this.color = this.type.color;
  }

  update() {
    this.vx += this.ax;
    this.vy += this.ay;
    this.x += this.vx;
    this.y += this.vy;
    this.checkBoundaries();
  }

  checkBoundaries() {
    if (this.x < 0 || this.x > width) this.vx *= -1;
    if (this.y < 0 || this.y > height) this.vy *= -1;
  }

  display() {
    fill(this.color);
    noStroke();
    ellipse(this.x, this.y, this.size);
  }
}

function checkCollisions() {
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      let p1 = particles[i];
      let p2 = particles[j];
      let d = dist(p1.x, p1.y, p2.x, p2.y);
      if (d < (p1.size + p2.size) / 2) {
        let tempVx = p1.vx;
        let tempVy = p1.vy;
        p1.vx = p2.vx;
        p1.vy = p2.vy;
        p2.vx = tempVx;
        p2.vy = tempVy;

        let sound = random(collisionSounds);
        sound.amp(0.5, 0.05);
        setTimeout(() => sound.amp(0, 0.1), 100);

        if (random() < 0.3 && particles.length < maxParticles) {
          let newType = random(colors);
          particles.push(new QuantumParticle((p1.x + p2.x) / 2, (p1.y + p2.y) / 2));
          particles[particles.length - 1].type = newType;
          particles[particles.length - 1].color = newType.color;
        }
      }
    }
  }
}
